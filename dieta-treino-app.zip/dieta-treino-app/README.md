
# App Dieta + Treino com Kiwify (PDF pós-pagamento)

## Como rodar

### Backend
```
cd server
cp .env.example .env
# edite .env e coloque seu link de checkout Kiwify (KIWIFY_CHECKOUT_URL)
npm i
npm start
```
O backend abre em http://localhost:3001

### Frontend (Vite + React)
```
cd ../frontend
cp .env.example .env
npm i
npm run dev
```
Abra http://localhost:5173

## Webhook na Kiwify
No painel Kiwify crie um webhook apontando para:
```
http://localhost:3001/webhooks/kiwify
```
Marque os eventos de pagamento aprovado. O botão "Baixar PDF" só libera quando o status ficar `paid`.
