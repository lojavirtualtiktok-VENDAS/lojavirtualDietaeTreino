
/* eslint-disable */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const PDFDocument = require('pdfkit');
const { nanoid } = require('nanoid');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Banco em memória (use Postgres/Redis em produção)
const orders = new Map();

function gerarPlano(objetivo) {
  const base = {
    definicao: {
      cafe: ['Omelete + 1 fatia pão integral', 'Iogurte desnatado + banana', 'Tapioca (ovo + queijo)'],
      almoco: ['Arroz + frango grelhado + salada', 'Batata doce + patinho moído + legumes', 'Peixe + purê de abóbora + brócolis'],
      lanche: ['Pão de queijo (pequeno) + café', 'Iogurte + maçã', 'Cuscuz + ovo'],
      janta: ['Peixe + salada de folhas', 'Frango grelhado + abóbora', 'Omelete + legumes refogados'],
      treinos: ['HIIT 20–25min', 'Musculação (12–15 reps) corpo todo', 'Cardio 30min + abdômen']
    },
    massa: {
      cafe: ['Pão + queijo + café', 'Omelete 3 ovos + tapioca', 'Iogurte + granola + banana'],
      almoco: ['Arroz + feijão + frango + legumes', 'Macarrão + carne moída + salada', 'Batata + peixe + cenoura'],
      lanche: ['Pão com frango + suco', 'Tapioca + queijo + banana', 'Cuscuz + ovo'],
      janta: ['Arroz + frango + brócolis', 'Batata + carne + salada', 'Omelete + mandioca'],
      treinos: ['Musculação pesada', 'Treino ABC com progressão', 'Força 5x5 + acessórios']
    }
  };
  return objetivo === 'Definição Muscular' ? base.definicao : base.massa;
}

// 1) Cria order intent e retorna URL de checkout Kiwify
app.post('/api/order-intents', (req, res) => {
  const { nome, email, cpf, telefone, idade, peso, altura, objetivo, genero } = req.body;
  const orderId = nanoid(12);

  orders.set(orderId, {
    orderId,
    status: 'pending',
    buyer: { nome, email, cpf, telefone },
    dados: { idade, peso, altura, objetivo, genero },
    plano: gerarPlano(objetivo)
  });

  const base = process.env.KIWIFY_CHECKOUT_URL; // ex.: https://pay.kiwify.com.br/xxxx
  const url = new URL(base);
  if (nome) url.searchParams.set('name', nome);
  if (email) url.searchParams.set('email', email);
  if (cpf) url.searchParams.set('cpf', cpf);
  if (telefone) url.searchParams.set('phone', telefone);
  url.searchParams.set('src', `order-${orderId}`); // volta no webhook

  return res.json({ orderId, checkoutUrl: url.toString() });
});

// 2) Webhook Kiwify → marca como pago
app.post('/webhooks/kiwify', (req, res) => {
  try {
    const event = req.body;
    const src = event?.src || event?.metadata?.src || event?.custom || '';
    const orderId = (src || '').toString().replace('order-', '');
    const status = (event?.status || event?.charge_status || event?.payment_status || '').toLowerCase();

    if (orderId && orders.has(orderId) && ['approved','paid','completed','succeeded'].includes(status)) {
      const current = orders.get(orderId);
      current.status = 'paid';
      current.gateway = { id: event?.id || event?.transaction_id, raw: event };
      orders.set(orderId, current);
    }
    return res.status(200).json({ received: true });
  } catch (e) {
    return res.status(200).json({ received: true });
  }
});

// 3) Consulta status
app.get('/api/orders/:id/status', (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'not found' });
  return res.json({ status: order.status });
});

// 4) PDF se pago
app.get('/api/orders/:id/pdf', (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).send('Pedido não encontrado');
  if (order.status !== 'paid') return res.status(402).send('Pagamento pendente');

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename=plano-${order.orderId}.pdf`);

  const doc = new PDFDocument({ margin: 50 });
  doc.pipe(res);

  doc.fontSize(18).text('Plano de Dieta e Treino', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text(`Cliente: ${order.buyer.nome} | Objetivo: ${order.dados.objetivo} | Gênero: ${order.dados.genero}`);
  doc.text(`Idade: ${order.dados.idade} | Peso: ${order.dados.peso}kg | Altura: ${order.dados.altura}cm`);
  doc.moveDown();

  const sec = (titulo, lista) => {
    doc.fontSize(14).text(titulo, { underline: true });
    doc.moveDown(0.3);
    lista.forEach((l, i) => doc.fontSize(12).text(`${i + 1}) ${l}`));
    doc.moveDown();
  };

  const p = order.plano;
  sec('Café da Manhã (3 opções)', p.cafe);
  sec('Almoço (3 opções)', p.almoco);
  sec('Lanche da Tarde (3 opções)', p.lanche);
  sec('Jantar (3 opções)', p.janta);
  sec('Treinos (3 opções)', p.treinos);

  doc.end();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));
