
import React, { useEffect, useState } from 'react'
import axios from 'axios'

function App() {
  const [form, setForm] = useState({
    nome: '', email: '', cpf: '', telefone: '',
    idade: '', peso: '', altura: '',
    objetivo: '', genero: ''
  })
  const [orderId, setOrderId] = useState('')
  const [status, setStatus] = useState('idle')

  const handle = (k, v) => setForm(s => ({ ...s, [k]: v }))

  async function criarIntent() {
    const { data } = await axios.post(import.meta.env.VITE_SERVER + '/api/order-intents', form)
    setOrderId(data.orderId)
    window.location.href = data.checkoutUrl
  }

  useEffect(() => {
    const idFromUrl = new URLSearchParams(window.location.search).get('order')
    if (idFromUrl) setOrderId(idFromUrl)
  }, [])

  async function checarStatus() {
    if (!orderId) return
    const { data } = await axios.get(import.meta.env.VITE_SERVER + `/api/orders/${orderId}/status`)
    setStatus(data.status)
  }

  function baixarPDF() {
    window.location.href = import.meta.env.VITE_SERVER + `/api/orders/${orderId}/pdf`
  }

  return (
    <div style={{maxWidth: 800, margin: '40px auto', fontFamily: 'sans-serif'}}>
      <h1>Plano de Dieta + Treino</h1>
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12}}>
        <input placeholder="Nome" value={form.nome} onChange={e=>handle('nome', e.target.value)} />
        <input placeholder="E-mail" value={form.email} onChange={e=>handle('email', e.target.value)} />
        <input placeholder="CPF (opcional)" value={form.cpf} onChange={e=>handle('cpf', e.target.value)} />
        <input placeholder="Telefone (opcional)" value={form.telefone} onChange={e=>handle('telefone', e.target.value)} />
        <input placeholder="Idade" value={form.idade} onChange={e=>handle('idade', e.target.value)} />
        <input placeholder="Peso (kg)" value={form.peso} onChange={e=>handle('peso', e.target.value)} />
        <input placeholder="Altura (cm)" value={form.altura} onChange={e=>handle('altura', e.target.value)} />
        <select value={form.objetivo} onChange={e=>handle('objetivo', e.target.value)}>
          <option value="">Objetivo</option>
          <option>Definição Muscular</option>
          <option>Ganho de Massa</option>
        </select>
        <select value={form.genero} onChange={e=>handle('genero', e.target.value)}>
          <option value="">Gênero</option>
          <option>Masculino</option>
          <option>Feminino</option>
        </select>
      </div>

      <div style={{marginTop: 16, display: 'flex', gap: 12}}>
        <button onClick={criarIntent}>Ir para pagamento</button>
        {orderId && <a href={`/?order=${orderId}`}>Salvar link do pedido</a>}
      </div>

      {orderId && (
        <div style={{marginTop: 24, padding: 12, border: '1px solid #ddd', borderRadius: 8}}>
          <div><b>Order:</b> {orderId}</div>
          <div><b>Status:</b> {status}</div>
          <div style={{display: 'flex', gap: 12, marginTop: 12}}>
            <button onClick={checarStatus}>Checar pagamento</button>
            <button onClick={baixarPDF} disabled={status !== 'paid'}>
              {status === 'paid' ? 'Baixar PDF' : 'Pagar para liberar PDF'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
