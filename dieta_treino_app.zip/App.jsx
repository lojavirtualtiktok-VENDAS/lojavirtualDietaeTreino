import React, { useState } from "react";
import { jsPDF } from "jspdf";

const KIWIFY_CHECKOUT_URL = "https://pay.kiwify.com.br/checkout/SEU_PRODUTO_AQUI";

function gerarOpcoesRefeicao({ idade, peso, altura, condFinanceira }) {
  const imc = peso / ((altura / 100) ** 2);
  const caloriasBase = imc < 18.5 ? 1800 : imc < 25 ? 2200 : 2500;

  const precos = {
    baixo: ["Banana + Aveia", "Pão integral + Queijo branco", "Iogurte natural com mel"],
    medio: ["Ovo mexido + Torrada integral", "Salada + Peito de frango grelhado", "Quinoa com legumes"],
    alto: ["Omelete com abacate e salmão defumado", "Bowl de salmão + arroz integral", "Tigela de açaí com granola premium"]
  };

  let bucket = "medio";
  if (condFinanceira === "baixo") bucket = "baixo";
  if (condFinanceira === "alto") bucket = "alto";

  const breakfast = precos[bucket].map((p, i) => `${i + 1}. ${p}`);
  const lunch = precos[bucket].map((p, i) => `${i + 1}. ${p} + salada`);
  const dinner = precos[bucket].map((p, i) => `${i + 1}. ${p} (versão leve)`);

  return { breakfast, lunch, dinner };
}

function gerarTreinos({ idade, peso, altura }) {
  const imc = peso / ((altura / 100) ** 2);
  let intensidade = "moderada";
  if (imc >= 30) intensidade = "leve";
  if (idade < 30 && imc < 25) intensidade = "intensa";

  const treinos = {
    leve: ["Caminhada 30min", "Yoga 30min", "Alongamento"],
    moderada: ["Corrida leve 30min", "Treino full-body 3x", "HIIT 15min"],
    intensa: ["Sprints 6x30s", "Musculação pesada 4x", "Cross training"]
  };

  return treinos[intensidade];
}

export default function App() {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ nome: "", idade: 25, peso: 70, altura: 170, condFinanceira: "medio" });
  const [pdfUrl, setPdfUrl] = useState(null);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }

  function handleGeneratePDF() {
    const { breakfast, lunch, dinner } = gerarOpcoesRefeicao(form);
    const treinos = gerarTreinos(form);

    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Plano Personalizado de Dieta e Treino", 14, 20);

    doc.setFontSize(12);
    doc.text(`Nome: ${form.nome}`, 14, 30);
    doc.text(`Idade: ${form.idade} | Peso: ${form.peso}kg | Altura: ${form.altura}cm`, 14, 38);
    doc.text(`Condição financeira: ${form.condFinanceira}`, 14, 46);

    doc.text("Café da manhã:", 14, 60);
    breakfast.forEach((b, i) => doc.text(b, 20, 70 + i * 8));

    doc.text("Almoço:", 14, 100);
    lunch.forEach((b, i) => doc.text(b, 20, 110 + i * 8));

    doc.text("Janta:", 14, 140);
    dinner.forEach((b, i) => doc.text(b, 20, 150 + i * 8));

    doc.text("Treinos:", 14, 180);
    treinos.forEach((b, i) => doc.text(b, 20, 190 + i * 8));

    const blob = doc.output("bloburl");
    setPdfUrl(blob);
  }

  function handlePay() {
    const url = KIWIFY_CHECKOUT_URL;
    window.open(url, "_blank");
  }

  return (
    <div className="min-h-screen bg-green-50 flex items-center justify-center p-6">
      <div className="max-w-3xl bg-white rounded-xl shadow-md p-6 w-full">
        <h1 className="text-3xl font-bold text-green-700 mb-4">Crie sua dieta e treino personalizado</h1>
        <p className="text-gray-700 mb-6">Monte seu plano e baixe em PDF agora mesmo!</p>

        {!showForm && (
          <div className="text-center">
            <p className="italic mb-3">"Transforme hábitos, construa resultados — comece hoje."</p>
            <button onClick={() => setShowForm(true)} className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full">
              Criar minha dieta e treino
            </button>
          </div>
        )}

        {showForm && (
          <div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <input name="nome" placeholder="Nome" className="border p-2 rounded" onChange={handleChange} />
              <input name="idade" type="number" placeholder="Idade" className="border p-2 rounded" onChange={handleChange} />
              <input name="peso" type="number" placeholder="Peso (kg)" className="border p-2 rounded" onChange={handleChange} />
              <input name="altura" type="number" placeholder="Altura (cm)" className="border p-2 rounded" onChange={handleChange} />
              <select name="condFinanceira" className="border p-2 rounded col-span-2" onChange={handleChange}>
                <option value="baixo">Baixa</option>
                <option value="medio">Média</option>
                <option value="alto">Alta</option>
              </select>
            </div>
            <div className="mt-4 flex gap-2">
              <button onClick={handleGeneratePDF} className="bg-blue-600 text-white px-4 py-2 rounded">Gerar PDF</button>
              <button onClick={handlePay} className="bg-green-600 text-white px-4 py-2 rounded">Pagar via Kiwify</button>
            </div>
            {pdfUrl && <a href={pdfUrl} target="_blank" rel="noreferrer" className="text-blue-600 underline block mt-2">Abrir PDF</a>}
          </div>
        )}
      </div>
    </div>
  );
}
